Bankeiz governance qualification

Unzip this folder and run node verify.mjs with Node.js 22 or later. All sources and verification code are included. The verifier checks the packaged test key, each enclosing Original, electoral closure, register custody and signed successor. The treasury package also checks the rollback-only SQL receipt and seeded balances against the approved installment. Two-sided signed Settlement recovery is separate.

qualification.json carries every exact Original. originals/ contains their identical decoded bytes. verify.mjs.map includes the corresponding verifier sources.
